## 爬取  百度广告联盟数据测试

 图片识别有些问题参照网上的方案对图片进行了一些优化

## 可选依赖安装

安装 tesseract
https://github.com/desmondmorris/node-tesseract

安装 gm
https://github.com/aheckmann/gm

## 忽略上面的步骤

第一步 确保安装了 node 和 npm 环境  
第二步 在项目目录下 npm i
第三步 确认张成本地验证码服务起了
第四步 访问http://localhost:9999/cd
